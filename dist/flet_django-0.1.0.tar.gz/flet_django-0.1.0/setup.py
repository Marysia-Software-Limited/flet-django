# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['flet_django',
 'flet_django.controls',
 'flet_django.management',
 'flet_django.management.commands']

package_data = \
{'': ['*']}

install_requires = \
['django>=4.0,<5.0', 'flet', 'flet-routed-app']

setup_kwargs = {
    'name': 'flet-django',
    'version': '0.1.0',
    'description': 'Django Flutter Framework.',
    'long_description': '# Django Flutter Framework\n\nDjango based desktop/mobile/web application.\n\n## Instalation\n- Install all python packages:\n\n        $ pip install -r requirements.txt\n- Migrate database:\n\n        $ python manage.py migrate\n\n## Run and usage\n- To run app use todo django command:\n\n        $ python manage.py todo\n- To run server use --view parameter:\n\n        $ python manage.py todo --view flet_app_hidden\n- Server will be avaible as http://$APP_HOST:$APP_PORT, default value is 8085, for example:\n\n        $ open http://ala.hipisi.org.pl:8085\n- Compile ./frontend futter app to have separate ready to install application:\n\n        $ cd frontend\n        $ flutter run --dart-entrypoint-args http://94.23.247.130:8085\n- You can use simple script to run separate flutter application:\n\n        $ python run.py\n\n## Demo\n\nWorking demo [is here](http://ala.hipisi.org.pl:8085).\n\n## Screenshots\n\n![Android app](./todo_pixel4.png)\n\n![iOS app](./todo_iphone14.png)\n',
    'author': 'beret',
    'author_email': 'beret@hipisi.org.pl',
    'maintainer': 'Marysia Software Limited',
    'maintainer_email': 'office@marysia.app',
    'url': 'https://marysia.app',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.11,<4.0',
}


setup(**setup_kwargs)
