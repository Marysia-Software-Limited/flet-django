from django.apps import AppConfig


class FletConfig(AppConfig):
    name = "flet_django"
    verbose_name = "Django Flutter Framework"
